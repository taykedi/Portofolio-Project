package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;

public interface VideoRepository extends JpaRepository<Video, Long> {
    // functionalitati pt interacțiunea cu baza de date
}
