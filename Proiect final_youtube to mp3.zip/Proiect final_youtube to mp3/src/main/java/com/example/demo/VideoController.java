package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/videos")
public class VideoController {

    @Autowired
    private VideoRepository videoRepository;

    // Endpoint GET pentru a returna toate videoclipurile
    @GetMapping
    public String getVideos(Model model) {
        List<Video> videos = videoRepository.findAll();
        model.addAttribute("videos", videos);
        return "videoList"; // va returna un template Thymeleaf
    }

    // Endpoint GET pentru un singur videoclip
    @GetMapping("/{id}")
    public String getVideo(@PathVariable Long id, Model model) {
        Video video = videoRepository.findById(id).orElse(null);
        model.addAttribute("video", video);
        return "videoDetail"; // va returna detaliile unui videoclip
    }

    // Endpoint POST pentru a adăuga un videoclip
    @PostMapping
    public String addVideo(@RequestParam String title, @RequestParam String url) {
        Video video = new Video();
        video.setTitle(title);
        video.setUrl(url);
        videoRepository.save(video);
        return "redirect:/videos"; // redirectioneaza la lista de videoclipuri
    }

    // Endpoint PUT pentru actualizarea unui videoclip
    @PutMapping("/{id}")
    public String updateVideo(@PathVariable Long id, @RequestParam String title, @RequestParam String url) {
        Video video = videoRepository.findById(id).orElse(null);
        if (video != null) {
            video.setTitle(title);
            video.setUrl(url);
            videoRepository.save(video);
        }
        return "redirect:/videos";
    }

    // Endpoint DELETE pentru ștergerea unui videoclip
    @DeleteMapping("/{id}")
    public String deleteVideo(@PathVariable Long id) {
        videoRepository.deleteById(id);
        return "redirect:/videos";
    }
}
